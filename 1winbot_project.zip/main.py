import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import CommandStart
from keep_alive import keep_alive  # Импортируем keep_alive

API_TOKEN = "7606465026:AAFISWZ2oBWSUh2WlnJxOaBTu2gFKQlMmnk"
ADMIN_ID = 6365370532

bot = Bot(token=API_TOKEN)
dp = Dispatcher()

users_verified = set()
pending_verification = {}

games_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🎯 Mines"), KeyboardButton(text="✈️ Aviator")],
        [KeyboardButton(text="🎲 Dice"), KeyboardButton(text="🚀 Lucky Jet")],
        [KeyboardButton(text="⚽ Penalty Shootout")]
    ],
    resize_keyboard=True
)

@dp.message(CommandStart())
async def start(message: types.Message):
    user_id = message.from_user.id
    if user_id in users_verified:
        await message.answer("🎮 Добро пожаловать обратно! Выберите игру:", reply_markup=games_kb)
    else:
        text = (
            "👋 Привет! Я — бот, который автоматически выдаёт сигналы для игр на платформе 1win.

"
            "🎯 Доступные игры:
"
            "  • Mines
"
            "  • Aviator
"
            "  • Dice
"
            "  • Lucky Jet
"
            "  • Penalty Shootout

"
            "🔎 Сигналы генерируются автоматически каждый раз, когда вы нажимаете на игру.
"
            "⚠️ Но сначала вам нужно пройти быструю регистрацию.

"
            "🔗 Зарегистрируйтесь по ссылке:
"
            "https://1wzyuh.com/?p=0nfd

"
            "🆔 Затем отправьте сюда свой ID от 1win для подтверждения доступа."
        )
        await message.answer(text)

@dp.message(F.text and F.text.isdigit())
async def receive_user_id(message: types.Message):
    user_id = message.from_user.id
    entered_id = message.text
    if user_id in users_verified:
        await message.answer("Вы уже подтверждены и можете получать сигналы.", reply_markup=games_kb)
        return

    pending_verification[user_id] = entered_id

    await message.answer("✅ Ваша заявка отправлена на проверку. Ожидайте подтверждения администратора.")

    confirm_kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Подтвердить", callback_data=f"admin_confirm_{user_id}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"admin_reject_{user_id}")
        ]
    ])

    await bot.send_message(
        ADMIN_ID,
        f"📥 Новая заявка:
Пользователь: {user_id}
ID 1win: {entered_id}",
        reply_markup=confirm_kb
    )

@dp.callback_query(F.data.startswith("admin_confirm_") | F.data.startswith("admin_reject_"))
async def admin_handle_decision(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("❌ Только админ может использовать эту кнопку.", show_alert=True)
        return

    data = callback.data
    action, user_id_str = data.split("_")[1], data.split("_")[2]
    user_id = int(user_id_str)

    if action == "confirm":
        if user_id in users_verified:
            await callback.answer("Пользователь уже подтверждён.")
            return
        users_verified.add(user_id)
        if user_id in pending_verification:
            del pending_verification[user_id]
        await bot.send_message(user_id, "✅ Ваша регистрация подтверждена! Теперь вы можете получать сигналы.", reply_markup=games_kb)
        await callback.message.edit_text(f"✅ Пользователь {user_id} подтверждён.")
        await callback.answer()

    elif action == "reject":
        if user_id in pending_verification:
            del pending_verification[user_id]
        await bot.send_message(user_id, "❌ Ваша заявка отклонена администратором.")
        await callback.message.edit_text(f"❌ Пользователь {user_id} отклонён.")
        await callback.answer()

@dp.message(F.text == "/admin")
async def admin_panel(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("❌ Эта команда доступна только администратору.")
        return

    text = "📋 Админ-панель

"

    if pending_verification:
        text += "⏳ Заявки на подтверждение:
"
        for uid, u1win in pending_verification.items():
            text += f"• Пользователь {uid}, ID 1win: {u1win}
"
    else:
        text += "Нет заявок на подтверждение.
"

    if users_verified:
        text += f"
✅ Подтверждённых пользователей: {len(users_verified)}
"
    else:
        text += "
Нет подтверждённых пользователей.
"

    mass_send_kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📡 Отправить сигнал всем", callback_data="admin_send_all_signals")]
    ])

    await message.answer(text, reply_markup=mass_send_kb)

@dp.callback_query(F.data == "admin_send_all_signals")
async def send_signals_to_all(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("❌ Только админ может использовать эту кнопку.", show_alert=True)
        return

    if not users_verified:
        await callback.answer("Нет подтверждённых пользователей для отправки сигналов.", show_alert=True)
        return

    for user_id in users_verified:
        signals = []
        for game in ["🎯 Mines", "✈️ Aviator", "🎲 Dice", "🚀 Lucky Jet", "⚽ Penalty Shootout"]:
            signals.append(f"{game}: {generate_signal(game)}")
        text = "📡 Массовый сигнал для всех игр:

" + "
".join(signals)
        try:
            await bot.send_message(user_id, text)
        except Exception as e:
            print(f"Не удалось отправить пользователю {user_id}: {e}")

    await callback.answer("Сигналы отправлены всем подтверждённым пользователям.")
    await callback.message.edit_text("✅ Массовая отправка сигналов завершена.")

@dp.message(F.text.in_(["🎯 Mines", "✈️ Aviator", "🎲 Dice", "🚀 Lucky Jet", "⚽ Penalty Shootout"]))
async def send_signal(message: types.Message):
    user_id = message.from_user.id
    if user_id not in users_verified:
        await message.answer("❗ Сначала отправьте свой ID для подтверждения.")
        return

    signal = generate_signal(message.text)
    await message.answer(f"📡 Сигнал для {message.text}:

{signal}")

def generate_signal(game):
    from random import choice
    if game == "🎯 Mines":
        return f"Открой: {choice(['1,4,7', '2,5,8', '3,6,9'])}"
    if game == "✈️ Aviator":
        return f"Играй до x{choice(['1.4', '1.6', '1.8'])}"
    if game == "🎲 Dice":
        return f"Ставь на: {choice(['<50', '>50', '=50'])}"
    if game == "🚀 Lucky Jet":
        return f"Жди до x{choice(['1.5', '1.7', '2.0'])}"
    if game == "⚽ Penalty Shootout":
        role = choice(["игрок", "вратарь"])
        direction = choice(["левый угол", "правый угол", "по центру"])
        if role == "игрок":
            return f"Ты — ⚽ нападающий. Бей в **{direction}**!"
        else:
            return f"Ты — 🧤 вратарь. Лови в **{direction}**!"
    return "Нет сигнала."

async def main():
    keep_alive()  # Запускаем веб-сервер для keep alive
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
